from setuptools import setup, find_packages

setup(
    name='Time_pause',
    version='1.0',
    license='MIT',
    author="PokechaNyaa",
    author_email='pokechan6446@gmail.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://github.com/Pokecraft-exe/time_pause',
    keywords='Project to pause time'
)